package com.smartcare.SmartCare.Kafka.Config;

public class AppConstants {
    public static final String RequestTopicName = "RequestToNgo";
    public static final String  GROUP_ID="group-1";
}
